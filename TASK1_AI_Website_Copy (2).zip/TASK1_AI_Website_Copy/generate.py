from openai import OpenAI
import os

client = OpenAI(api_key=os.getenv("sk-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"))

# Read master prompt
with open("PROMPT/master_prompt.txt", "r", encoding="utf-8") as f:
    master_prompt = f.read()

# Read business input
with open("EXAMPLES/input_txt", "r", encoding="utf-8") as f:
    business_input = f.read()

full_prompt = master_prompt + "\n\nBusiness Information:\n" + business_input

response = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[
        {"role": "user", "content": full_prompt}
    ]
)

output_text = response.choices[0].message.content

# Save output
with open("EXAMPLES/output_txt", "w", encoding="utf-8") as f:
    f.write(output_text)

print("✅ Website copy generated and saved in EXAMPLES/output_txt")