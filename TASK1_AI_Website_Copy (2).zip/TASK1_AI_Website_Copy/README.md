# AI Website Copy Generator (TASK1)

## Project Overview
This project uses Prompt Engineering and AI to generate professional website copy for local businesses.

## Business Chosen
LuxeGlow Beauty Salon - Hyderabad, Telangana

## Folder Structure
TASK1/
PROMPT/ -> master_prompt.txt (AI instructions)
EXAMPLES/ -> input_txt (business info), output_txt (AI output)
copy.py -> Python script to generate website copy
README.md -> Project explanation

## How to Run
1. Install Python
2. Install OpenAI library:
   pip install openai
3. Set API key:
   setx OPENAI_API_KEY "your_api_key_here"
4. Run:
   python copy.py

## Output
Generated website copy will appear in:
EXAMPLES/output_txt
